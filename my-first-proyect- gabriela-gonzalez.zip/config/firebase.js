 export default {
    apiKey: "AIzaSyC6qacnBC4BiMGx56vYFESs-U5GFiSlPvg",
    authDomain: "myfirstproyect-8aa5b.firebaseapp.com",
    databaseURL: "https://myfirstproyect-8aa5b.firebaseio.com",
    projectId: "myfirstproyect-8aa5b",
    storageBucket: "myfirstproyect-8aa5b.appspot.com",
    messagingSenderId: "378127547909",
    appId: "1:378127547909:web:904068e40d845455e9e66c"
  }